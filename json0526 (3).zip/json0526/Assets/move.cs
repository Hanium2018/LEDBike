﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;

public class move : MonoBehaviour
{
    Vector3 End_pos;
    Vector3 Start_pos;
    public float fracton_of_way_there;
    string end_x;
    int x;
    string jsonData;
    string str_x;


    // Use this for initialization
    void Start()
    {

        StartCoroutine(WaitForRequest(5.0f));
    }

    IEnumerator WaitForRequest(float delayTime)
    {
        string url = "http://localhost:5000/getList";
        WWW www = new WWW(url);

        Start_pos = transform.position;
        fracton_of_way_there += 0.01f;
        yield return www;
        //string jsonData = "";


        // check for errors
        if (string.IsNullOrEmpty(www.error))
        {
            jsonData = www.text;
            var N = JSON.Parse(jsonData);
            //Debug.Log("json " + N["x"].ToString());

            str_x = N["x"].ToString();
           // Debug.Log(str_x);
           // Debug.Log(str_x.GetType());
			string a = str_x.Substring(1,1);
			Debug.Log(a);
			
			
			//int a = str_x.Length;
			//Debug.Log(a);
            x = System.Int32.Parse(a);
           // x = System.Convert.ToInt32(str_x);

            End_pos = new Vector3(x, 0, 0);
            transform.position = Vector3.Lerp(Start_pos, End_pos, fracton_of_way_there);
            StartCoroutine(WaitForRequest(5.0f));

        }
        else
        {
            Debug.Log("WWW Error: " + www.error);
        }
    } 
}