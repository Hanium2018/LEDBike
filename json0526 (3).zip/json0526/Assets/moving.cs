﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;
using System.Timers;

public class moving : MonoBehaviour {
    Vector3 End_pos;
    Vector3 Start_pos;
    public float fracton_of_way_there;
    string end_x;
    string m,n,b;
    int x;


	// Use this for initialization
	void Start () {
        
        StartCoroutine(WaitForRequest(5.0f));
	}

    IEnumerator WaitForRequest(float delayTime)
    {   
       string url = "http://localhost:5000/getList";
       WWW www = new WWW(url);
       
        Start_pos = transform.position;
        fracton_of_way_there += 0.01f;
        
        yield return www;

        // check for errors
        if (www.error == null)
        {
            var j = JSON.Parse(www.text);
            //string val = j["Employees"]["x\n"];
            string val = j["Info"];
            m = val.Substring(8,1);
            n = val.Substring(23, 1);
            x = System.Convert.ToInt32(m);
            Debug.Log(m);

            End_pos = new Vector3(x*2, 0, 0);
            //end_x = System.Convert.ToInt32(json["Employees"]["x"].str);
            //end_x = json["Employee"]["x"].str;

            transform.position = Vector3.Lerp(Start_pos, End_pos, fracton_of_way_there);
            waitForSeconds(3.0f);
            StartCoroutine(WaitForRequest(5.0f));
            
        }
        else
        {
            Debug.Log("WWW Error: " + www.error);
        }
    }

    IEnumerator waitForSeconds(float a){
        yield return new WaitForSeconds(a);
    }
    // Update is called once per frame
    void Update () {

    }

}
