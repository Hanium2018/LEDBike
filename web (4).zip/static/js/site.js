function printTime(){
	var clock = document.getElementById("clock");
	var now = new Date();
	        
	clock.innerHTML = now.getDate()+" / "+ (now.getMonth()+1) + " / "+ now.getFullYear() +"　" +now.getHours()+":"+
	now.getMinutes() + (now.getHours() >= 12 ? "PM" : "AM");
	
	setTimeout("printTime()", 1000);
}

window.onload = function(){
	//printTime();
};