#-*- coding:utf-8 -*-
from flask import Flask, json
from collections import OrderedDict
from random import *

import json
import requests

# appKey = "803c711c-8526-4827-93d2-04a3d2fffb4d" # ?? appkey
appKey = "decc3ab2-9d99-4820-aa77-f5a00cd99a0c" # ?? appkey

url = "https://api2.sktelecom.com/weather/current/hourly"
headers = {'Content-Type': 'application/json; charset=utf-8', 'appKey': appKey}
params = { "version": "1", "city": "서울", "county" : "노원구", "village": "중계본동"}
response = requests.get(url, params=params, headers=headers)

if response.status_code==200:
    response_body = response.json()
    response_json = json.dumps(response_body)
    response_dict = json.loads(response_json)
    # print(response_json)
    temperature = response_dict['weather']['hourly'][0]['temperature']['tc']
    sky_code = response_dict['weather']['hourly'][0]['sky']['code']

app = Flask(__name__)

@app.route("/getList")
def getList():

    a = str(randint (1, 100))
    b = str (randint (1,100))
    c = str(randint (-5,5))
    d = str(randint (1,100))
    e = temperature
    f = sky_code

    sensor = OrderedDict()
    sensor["speed"] = a
    sensor["distance"] = b
    sensor["position"] = c
    sensor["heart"] = d
    sensor["tempt"] = e
    sensor['cloud'] =f

    return(json.dumps(sensor, ensure_ascii =False, indent = "\t"))

if __name__ == '__main__':
   app.run(debug=True)
