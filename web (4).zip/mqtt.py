# -*- coding: utf-8 -*-
from __future__ import print_function

import requests
from flask import redirect, url_for
import json
import paho.mqtt.client as mqtt
import mysql.connector

count = 0
ice = 0
weather = "weather"
data = 0
val_distance =0
val_speed_avg =0
val_heartbeat = 0
cnt = 0
column = "s1"
MQTT_SERVER = "iot.eclipse.org"
MQTT_PATH = "hoo/#"
client = mqtt.Client()
arduino_data = None

# appKey = "803c711c-8526-4827-93d2-04a3d2fffb4d" # ?? appkey
appKey = "decc3ab2-9d99-4820-aa77-f5a00cd99a0c" # ?? appkey

url = "https://api2.sktelecom.com/weather/current/hourly"
headers = {'Content-Type': 'application/json; charset=utf-8', 'appKey': appKey}
params = { "version": "1", "city": "서울", "county" : "노원구", "village": "중계본동"}
response = requests.get(url, params=params, headers=headers)

if response.status_code==200:
    response_body = response.json()
    response_json = json.dumps(response_body)
    response_dict = json.loads(response_json)
    # print(response_json)
    temperature = response_dict['weather']['hourly'][0]['temperature']['tc']
    sky_code = response_dict['weather']['hourly'][0]['sky']['code']


def on_connect(client, userdata, flags, rc):
    print("connect result" + str(rc))
    client.subscribe(MQTT_PATH)

def on_message(client, userdata, msg):
    global count
    global column
    global ice
    global cnt
    global data
    global val_distance
    global val_spped
    global val_speed_avg
    global val_heartbeat
    global arduino_data


    if count<36:

        if (msg.topic == "hoo/distance"):
            val_distance = float(str(msg.payload.decode("utf-8")))
            print("val_distance : {}".format(val_distance))
        if (msg.topic == "hoo/heartbeat"):
            val_heartbeat = float(str(msg.payload.decode("utf-8")))
            print("heartbeat : {}".format(val_heartbeat))
        if (msg.topic == "hoo/avg"):
            val_speed = float(str(msg.payload.decode("utf-8")))
            val_speed_avg = val_speed*5
            conn = mysql.connector.connect(user="raspberrypi", password="raspberrypi",
                                           host="raspberrydb.cvlmaax7vr80.ap-northeast-2.rds.amazonaws.com",
                                           database="raspberrypi", port=3306)

            cursor = conn.cursor(buffered=True)
            query = "SELECT nickname, you_nickname, yourteam FROM customer ORDER BY id DESC LIMIT 1"
            cursor.execute(query)
            rows = cursor.fetchall()
            for row in rows:
                my_nickname = row[0]
                your_nickname = row[1]
                your_team = row[2]
            cursor.execute("UPDATE speed3 SET {} = {} WHERE nickname = '{}'".format(column, val_speed_avg, my_nickname))
            count += 1
            conn.commit()



            if your_nickname:
                cursor.execute("SELECT {} FROM speed3 where nickname = '{}'".format(column, your_nickname))
                column_data = cursor.fetchall()
                row = float(str(column_data[0][0]))
                column_number = int(column[1:])
                column_number += 1
                column = column[0] + str(column_number)

                if (val_speed_avg - float(row)) > 24.0:
                    ice = 20
                elif (val_speed_avg - float(row)) > 18.0:
                    ice = 18
                elif (val_speed_avg - float(row)) > 13.0:
                    ice = 16
                elif (val_speed_avg - float(row)) > 10.0:
                    ice = 14
                elif (val_speed_avg - float(row)) > 7.0:
                    ice = 12
                elif (val_speed_avg - float(row)) > 5.0:
                    ice = 10
                elif (val_speed_avg - float(row)) > 4.0:
                    ice = 8
                elif (val_speed_avg - float(row)) > 3.0:
                    ice = 6
                elif (val_speed_avg - float(row)) > 2.0:
                    ice = 4
                elif (val_speed_avg - float(row)) > 1.0:
                    ice = 2
                elif (val_speed_avg - float(row)) > 0.0:
                    ice = 0
                elif (val_speed_avg - float(row)) > -2.0:
                    ice = -2
                elif (val_speed_avg - float(row)) > -4.0:
                    ice = -4
                elif (val_speed_avg - float(row)) > -6.0:
                    ice = -6
                elif (val_speed_avg - float(row)) > -8.0:
                    ice = -8
                elif (val_speed_avg - float(row)) > -10.0:
                    ice = -10
                elif (val_speed_avg - float(row)) > -12.0:
                    ice = -12
                elif (val_speed_avg - float(row)) > -14.0:
                    ice = -14
                elif (val_speed_avg - float(row)) > -16.0:
                    ice = -16
                elif (val_speed_avg - float(row)) > -18.0:
                    ice = -18
                elif (val_speed_avg - float(row)) > -20.0:
                    ice = -20
                print(ice)

            if your_team:
                cursor.execute("SELECT avg(s1), avg(s2), avg(s3), avg(s4) FROM speed3 where id in (select id from customer where myteam = '{}')".format(your_team))
                column_data = cursor.fetchall()
                row = float(str(column_data[0][0]))
                column_number = int(column[1:])
                column_number += 1
                column = column[0] + str(column_number)
                print(float(row))
                if (val_speed_avg - float(row)) > 24.0:
                    ice = 20
                elif (val_speed_avg - float(row)) > 18.0:
                    ice = 18
                elif (val_speed_avg - float(row)) > 13.0:
                    ice = 16
                elif (val_speed_avg - float(row)) > 10.0:
                    ice = 14
                elif (val_speed_avg - float(row)) > 7.0:
                    ice = 12
                elif (val_speed_avg - float(row)) > 5.0:
                    ice = 10
                elif (val_speed_avg - float(row)) > 4.0:
                    ice = 8
                elif (val_speed_avg - float(row)) > 3.0:
                    ice = 6
                elif (val_speed_avg - float(row)) > 2.0:
                    ice = 4
                elif (val_speed_avg - float(row)) > 1.0:
                    ice = 2
                elif (val_speed_avg - float(row)) > 0.0:
                    ice = 0
                elif (val_speed_avg - float(row)) > -2.0:
                    ice = -2
                elif (val_speed_avg - float(row)) > -4.0:
                    ice = -4
                elif (val_speed_avg - float(row)) > -6.0:
                    ice = -6
                elif (val_speed_avg - float(row)) > -8.0:
                    ice = -8
                elif (val_speed_avg - float(row)) > -10.0:
                    ice = -10
                elif (val_speed_avg - float(row)) > -12.0:
                    ice = -12
                elif (val_speed_avg - float(row)) > -14.0:
                    ice = -14
                elif (val_speed_avg - float(row)) > -16.0:
                    ice = -16
                elif (val_speed_avg - float(row)) > -18.0:
                    ice = -18
                elif (val_speed_avg - float(row)) > -20.0:
                    ice = -20
                print(ice)



            arduino_data = {}
            arduino_data["position"] = ice
            arduino_data["distance"] = val_distance
            arduino_data["speed"] = val_speed_avg
            arduino_data["heartbeat"] = val_heartbeat
            arduino_data["temp"] = temperature
            arduino_data["sky"] = sky_code

            if count == 36:
                arduino_data["count"] = "stop"

            data = json.dumps(arduino_data)
    else:
        column = "s1"
        print("close")
        stop()
        count=0


def sstart():
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_SERVER, 1883, 60)
    client.loop_start()

def stop():
    client.loop_stop()

# conn.close()
